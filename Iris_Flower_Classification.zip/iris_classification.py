# Iris Flower Classification
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
data = pd.read_csv("iris.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset information:")
print(data.info())

print("\nSpecies distribution:")
print(data["species"].value_counts())

# Features and target
X = data[["sepal_length", "sepal_width", "petal_length", "petal_width"]]
y = data["species"]

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train classification model
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)

# Predict test data
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"\nModel Accuracy: {accuracy * 100:.2f}%")

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Predict a new flower
new_flower = [[5.1, 3.5, 1.4, 0.2]]
prediction = model.predict(new_flower)
print("\nNew flower prediction:", prediction[0])

# Visualization
plt.figure(figsize=(8, 5))
for species in data["species"].unique():
    subset = data[data["species"] == species]
    plt.scatter(
        subset["petal_length"],
        subset["petal_width"],
        label=species
    )

plt.xlabel("Petal Length")
plt.ylabel("Petal Width")
plt.title("Iris Flower Classification")
plt.legend()
plt.tight_layout()
plt.savefig("iris_classification.png", dpi=150)
plt.show()
