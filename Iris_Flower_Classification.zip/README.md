# Iris Flower Classification

## Synopsis
This project classifies iris flowers into three species using sepal and petal measurements.

## Objectives
- Understand the Iris dataset.
- Analyze flower features.
- Train a classification model.
- Predict the species of a new flower.
- Check model accuracy.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- sepal_length
- sepal_width
- petal_length
- petal_width
- species

## Algorithm
K-Nearest Neighbors (KNN) with k=5.

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python iris_classification.py

The program displays sample data, species distribution, accuracy, classification report, confusion matrix, and prediction for a new flower. It also creates `iris_classification.png`.

## Sample New Flower
Sepal Length = 5.1
Sepal Width = 3.5
Petal Length = 1.4
Petal Width = 0.2

The model predicts the species based on these measurements.
